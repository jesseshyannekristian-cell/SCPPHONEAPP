import Database from "better-sqlite3";
import { join, dirname } from "path";
import { fileURLToPath } from "url";
import { mkdirSync, existsSync } from "fs";

const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = join(__dirname, "../data");
const DB_PATH = join(DATA_DIR, "site24.db");

if (!existsSync(DATA_DIR)) mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    userId          TEXT PRIMARY KEY,
    username        TEXT NOT NULL,
    quizScore       INTEGER NOT NULL DEFAULT 0,
    captureAttempts INTEGER NOT NULL DEFAULT 10,
    lastDailyClaim  TEXT,
    collection      TEXT NOT NULL DEFAULT '[]',
    totalCaptures   INTEGER NOT NULL DEFAULT 0,
    joinedAt        TEXT NOT NULL
  )
`);

db.exec(`
  CREATE TABLE IF NOT EXISTS archive_documents (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    documentId  TEXT NOT NULL UNIQUE,
    category    TEXT NOT NULL,
    title       TEXT NOT NULL,
    content     TEXT NOT NULL,
    authorId    TEXT NOT NULL,
    authorName  TEXT NOT NULL,
    status      TEXT NOT NULL DEFAULT 'Archived',
    createdAt   TEXT NOT NULL
  )
`);

export interface UserData {
  userId: string;
  username: string;
  quizScore: number;
  captureAttempts: number;
  lastDailyClaim: string | null;
  collection: string[];
  totalCaptures: number;
  joinedAt: string;
}

interface UserRow extends Omit<UserData, "collection"> {
  collection: string;
}

function rowToUser(row: UserRow): UserData {
  return { ...row, collection: JSON.parse(row.collection) as string[] };
}

const stmtGet    = db.prepare<[string], UserRow>("SELECT * FROM users WHERE userId = ?");
const stmtInsert = db.prepare<[string, string, string]>(
  "INSERT INTO users (userId, username, captureAttempts, joinedAt) VALUES (?, ?, 10, ?)"
);
const stmtUpdateUsername = db.prepare<[string, string]>(
  "UPDATE users SET username = ? WHERE userId = ?"
);

export function getUser(userId: string, username: string): UserData {
  let row = stmtGet.get(userId);
  if (!row) {
    stmtInsert.run(userId, username, new Date().toISOString());
    row = stmtGet.get(userId)!;
  } else if (row.username !== username) {
    stmtUpdateUsername.run(username, userId);
    row.username = username;
  }
  return rowToUser(row);
}

export function updateUser(userId: string, updates: Partial<UserData>): UserData {
  const row = stmtGet.get(userId);
  if (!row) throw new Error(`User ${userId} not found`);

  const fields: string[] = [];
  const values: (string | number | null)[] = [];

  for (const [key, val] of Object.entries(updates)) {
    if (key === "userId") continue;
    fields.push(`${key} = ?`);
    values.push(key === "collection" ? JSON.stringify(val) : (val as string | number | null));
  }

  if (fields.length > 0) {
    values.push(userId);
    db.prepare(`UPDATE users SET ${fields.join(", ")} WHERE userId = ?`).run(...values);
  }

  return rowToUser(stmtGet.get(userId)!);
}

export function getAllUsers(): UserData[] {
  return (db.prepare("SELECT * FROM users").all() as UserRow[]).map(rowToUser);
}

export function isNewDay(lastClaim: string | null): boolean {
  if (!lastClaim) return true;
  const last = new Date(lastClaim);
  const now = new Date();
  const lastUTC = new Date(Date.UTC(last.getUTCFullYear(), last.getUTCMonth(), last.getUTCDate()));
  const nowUTC  = new Date(Date.UTC(now.getUTCFullYear(),  now.getUTCMonth(),  now.getUTCDate()));
  return nowUTC > lastUTC;
}

export function getTimeUntilReset(): string {
  const now = new Date();
  const tomorrow = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() + 1));
  const diff = tomorrow.getTime() - now.getTime();
  const hours   = Math.floor(diff / (1000 * 60 * 60));
  const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  return `${hours}h ${minutes}m`;
}


export type ArchiveCategory = "incident" | "brief" | "anomaly" | "mtf" | "personnel" | "scp";

export interface ArchiveDocument {
  id: number;
  documentId: string;
  category: ArchiveCategory;
  title: string;
  content: string;
  authorId: string;
  authorName: string;
  status: string;
  createdAt: string;
}

const archivePrefixes: Record<ArchiveCategory, string> = {
  incident: "IR",
  brief: "BR",
  anomaly: "AA",
  mtf: "MTF",
  personnel: "PD",
  scp: "SCP",
};

function makeDocumentId(category: ArchiveCategory): string {
  const prefix = archivePrefixes[category];
  const year = new Date().getUTCFullYear();
  const row = db.prepare<[string], { count: number }>(
    "SELECT COUNT(*) as count FROM archive_documents WHERE documentId LIKE ?"
  ).get(`${prefix}-${year}-%`);
  const nextNumber = String((row?.count ?? 0) + 1).padStart(4, "0");
  return `${prefix}-${year}-${nextNumber}`;
}

export function createArchiveDocument(input: {
  category: ArchiveCategory;
  title: string;
  content: string;
  authorId: string;
  authorName: string;
}): ArchiveDocument {
  const createdAt = new Date().toISOString();
  const documentId = makeDocumentId(input.category);

  db.prepare(
    `INSERT INTO archive_documents
      (documentId, category, title, content, authorId, authorName, status, createdAt)
     VALUES (?, ?, ?, ?, ?, ?, 'Archived', ?)`
  ).run(documentId, input.category, input.title, input.content, input.authorId, input.authorName, createdAt);

  return db.prepare<[string], ArchiveDocument>(
    "SELECT * FROM archive_documents WHERE documentId = ?"
  ).get(documentId)!;
}

export function getRecentArchiveDocuments(category: ArchiveCategory, limit = 10): ArchiveDocument[] {
  return db.prepare<[ArchiveCategory, number], ArchiveDocument>(
    "SELECT * FROM archive_documents WHERE category = ? ORDER BY createdAt DESC LIMIT ?"
  ).all(category, limit);
}

export function searchArchiveDocuments(category: ArchiveCategory, query: string, limit = 10): ArchiveDocument[] {
  const like = `%${query}%`;
  return db.prepare<[ArchiveCategory, string, string, string, number], ArchiveDocument>(
    `SELECT * FROM archive_documents
     WHERE category = ? AND (title LIKE ? OR content LIKE ? OR documentId LIKE ?)
     ORDER BY createdAt DESC LIMIT ?`
  ).all(category, like, like, like, limit);
}
