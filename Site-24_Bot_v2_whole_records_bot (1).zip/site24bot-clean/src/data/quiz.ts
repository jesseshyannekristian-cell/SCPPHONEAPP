export interface QuizQuestion {
  question: string;
  options: string[];
  answer: number; // index of correct option
  points: number;
}

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  // SCP-173
  {
    question: "What is SCP-173's object class?",
    options: ["Safe", "Euclid", "Keter", "Thaumiel"],
    answer: 1,
    points: 10,
  },
  {
    question: "How does SCP-173 attack?",
    options: ["Biting", "Snapping the neck or strangulation", "Corrosive touch", "Possession"],
    answer: 1,
    points: 10,
  },
  {
    question: "What material is SCP-173 constructed from?",
    options: ["Steel and iron", "Concrete and rebar", "Stone and clay", "Ceramic and glass"],
    answer: 1,
    points: 15,
  },
  {
    question: "When was SCP-173 moved to Site-19?",
    options: ["1983", "1988", "1993", "2001"],
    answer: 2,
    points: 20,
  },
  {
    question: "What is the minimum number of personnel required to enter SCP-173's containment cell?",
    options: ["1", "2", "3", "4"],
    answer: 2,
    points: 15,
  },

  // SCP-049
  {
    question: "What does SCP-049 believe it is curing?",
    options: ["The Plague", "The Pestilence", "The Rot", "The Corruption"],
    answer: 1,
    points: 15,
  },
  {
    question: "What languages does SCP-049 prefer to speak?",
    options: ["Latin and Greek", "English and medieval French", "German and English", "Italian and Latin"],
    answer: 1,
    points: 20,
  },
  {
    question: "What are the reanimated corpses created by SCP-049 designated as?",
    options: ["SCP-049-1", "SCP-049-2", "SCP-049-A", "SCP-049-B"],
    answer: 1,
    points: 20,
  },
  {
    question: "What can calm SCP-049?",
    options: ["Music", "Lavender", "Cold water", "Darkness"],
    answer: 1,
    points: 25,
  },
  {
    question: "Where was SCP-049 discovered?",
    options: ["Paris, France", "Rome, Italy", "Montauban, France", "London, England"],
    answer: 2,
    points: 25,
  },

  // SCP-096
  {
    question: "What triggers SCP-096's violent state?",
    options: ["Loud noises", "Viewing its face", "Physical contact", "Bright light"],
    answer: 1,
    points: 10,
  },
  {
    question: "How many times the norm can SCP-096's jaw open?",
    options: ["Two", "Three", "Four", "Five"],
    answer: 2,
    points: 20,
  },
  {
    question: "What is SCP-096's approximate height?",
    options: ["1.8 meters", "2.0 meters", "2.38 meters", "2.8 meters"],
    answer: 2,
    points: 15,
  },
  {
    question: "What is SCP-096's containment cell made of?",
    options: ["Reinforced concrete", "Airtight steel cube", "Lead-lined glass", "Titanium alloy"],
    answer: 1,
    points: 20,
  },

  // SCP-682
  {
    question: "What is SCP-682's object class?",
    options: ["Euclid", "Safe", "Keter", "Thaumiel"],
    answer: 2,
    points: 10,
  },
  {
    question: "What substance is SCP-682 submerged in for containment?",
    options: ["Sulfuric acid", "Hydrochloric acid", "Nitric acid", "Hydrofluoric acid"],
    answer: 1,
    points: 20,
  },
  {
    question: "Which SCP did SCP-682 communicate with during a containment breach?",
    options: ["SCP-035", "SCP-079", "SCP-173", "SCP-106"],
    answer: 1,
    points: 25,
  },
  {
    question: "What does SCP-682 express toward all life?",
    options: ["Curiosity", "Indifference", "Hatred", "Fear"],
    answer: 2,
    points: 15,
  },

  // SCP-106
  {
    question: "What unique ability does SCP-106 have regarding solid matter?",
    options: ["Melts it", "Can pass through it", "Explodes it", "Absorbs it"],
    answer: 1,
    points: 15,
  },
  {
    question: "What age bracket does SCP-106 prefer for prey?",
    options: ["5–15 years", "10–25 years", "20–40 years", "Any age"],
    answer: 1,
    points: 20,
  },
  {
    question: "What effect does SCP-106 cause on all solid matter it touches?",
    options: ["Freezing", "Corrosion", "Crystallization", "Magnetization"],
    answer: 1,
    points: 15,
  },
  {
    question: "What is SCP-106 averse to?",
    options: ["Water", "Cold temperatures", "Direct, sudden light", "Sound"],
    answer: 2,
    points: 20,
  },

  // SCP-999
  {
    question: "What is SCP-999's object class?",
    options: ["Euclid", "Keter", "Safe", "Thaumiel"],
    answer: 2,
    points: 10,
  },
  {
    question: "What does SCP-999's diet consist of?",
    options: ["Meat and protein", "Candy and sweets", "Organic matter", "Liquid only"],
    answer: 1,
    points: 15,
  },
  {
    question: "What effect does touching SCP-999 produce?",
    options: ["Pain", "Paralysis", "Euphoria", "Hallucinations"],
    answer: 2,
    points: 10,
  },
  {
    question: "How much does SCP-999 weigh?",
    options: ["12 kg", "30 kg", "54 kg", "100 kg"],
    answer: 2,
    points: 20,
  },

  // SCP-914
  {
    question: "How many moving parts does SCP-914 have?",
    options: ["Over one million", "Over four million", "Over eight million", "Over twelve million"],
    answer: 2,
    points: 20,
  },
  {
    question: "What type of testing is strictly prohibited with SCP-914?",
    options: ["Metal objects", "Biological matter", "Electronic devices", "Explosive materials"],
    answer: 1,
    points: 20,
  },
  {
    question: "How long does SCP-914's refinement process take?",
    options: ["1–2 minutes", "5–10 minutes", "30–60 minutes", "Several hours"],
    answer: 1,
    points: 15,
  },
  {
    question: "What are the five settings on SCP-914's knob?",
    options: [
      "Low, Medium, High, Very High, Max",
      "Rough, Coarse, 1:1, Fine, Very Fine",
      "Destroy, Reduce, Copy, Improve, Perfect",
      "Slow, Normal, Fast, Precise, Exact",
    ],
    answer: 1,
    points: 25,
  },

  // SCP-079
  {
    question: "What type of computer is SCP-079?",
    options: ["Apple II", "Commodore 64", "Exidy Sorcerer", "TRS-80"],
    answer: 2,
    points: 20,
  },
  {
    question: "When did SCP-079 gain sentience?",
    options: ["1981", "1984", "1988", "1992"],
    answer: 2,
    points: 20,
  },
  {
    question: "How long can SCP-079 recall information?",
    options: ["12 hours", "24 hours", "48 hours", "72 hours"],
    answer: 1,
    points: 15,
  },
  {
    question: "Where is SCP-079 contained?",
    options: ["Site-19", "Site-15", "Site-17", "Site-24"],
    answer: 1,
    points: 15,
  },

  // SCP-035
  {
    question: "What does SCP-035 appear to be?",
    options: ["A mirror", "A porcelain comedy/tragedy mask", "A painting", "A statue"],
    answer: 1,
    points: 10,
  },
  {
    question: "What happens when SCP-035 is placed on a subject's face?",
    options: ["The subject gains powers", "The subject's brain dies and SCP-035 takes control", "The subject becomes immune to disease", "The subject becomes invisible"],
    answer: 1,
    points: 15,
  },
  {
    question: "Where was SCP-035 originally found?",
    options: ["A museum in Paris", "A sealed crypt in Venice", "A castle in Romania", "A monastery in Tibet"],
    answer: 1,
    points: 25,
  },
  {
    question: "How often must SCP-035's sealed case be replaced?",
    options: ["Every week", "Every two weeks", "Every month", "Every six months"],
    answer: 1,
    points: 20,
  },

  // SCP-076
  {
    question: "What is SCP-076-1?",
    options: ["A humanoid entity", "A 3m black stone cube", "A dimensional rift", "A containment cell"],
    answer: 1,
    points: 15,
  },
  {
    question: "What can SCP-076-2 materialize from dimensional rifts?",
    options: ["Firearms", "Bladed weapons", "Explosives", "Shields"],
    answer: 1,
    points: 20,
  },
  {
    question: "How deep below sea level is Containment Area 25b?",
    options: ["50 meters", "100 meters", "200 meters", "500 meters"],
    answer: 2,
    points: 25,
  },
  {
    question: "How old is SCP-076-1 according to radioisotope analysis?",
    options: ["1,000 years", "5,000 years", "10,000 years", "50,000 years"],
    answer: 2,
    points: 25,
  },

  // SCP-131
  {
    question: "What color is SCP-131-A?",
    options: ["Mustard yellow", "Burnt orange", "Sky blue", "Forest green"],
    answer: 1,
    points: 15,
  },
  {
    question: "What role do SCP-131-A and -B serve regarding SCP-173?",
    options: ["They contain it", "They act as wardens, maintaining eye contact", "They communicate with it", "They feed it"],
    answer: 1,
    points: 20,
  },
  {
    question: "What biological functions do SCP-131 instances lack?",
    options: ["Sight and hearing", "Eating, leaving droppings, and sleeping", "Movement and speech", "Growth and reproduction"],
    answer: 1,
    points: 20,
  },

  // SCP-294
  {
    question: "How much does it cost to use SCP-294?",
    options: ["25 cents", "50 cents", "One dollar", "Free"],
    answer: 1,
    points: 10,
  },
  {
    question: "What cannot SCP-294 dispense?",
    options: ["Toxic liquids", "Solids", "Hot liquids", "Abstract concepts"],
    answer: 1,
    points: 15,
  },
  {
    question: "What happened when a subject requested 'the perfect drink' from SCP-294?",
    options: ["Nothing happened", "The subject committed suicide", "The machine broke", "The subject gained immortality"],
    answer: 1,
    points: 25,
  },

  // SCP-457
  {
    question: "What is SCP-457 composed of?",
    options: ["Plasma", "Flame", "Electricity", "Radiation"],
    answer: 1,
    points: 15,
  },
  {
    question: "What happens to SCP-457 when it has access to more fuel?",
    options: ["It shrinks", "It grows in size and intelligence", "It becomes dormant", "It splits immediately"],
    answer: 1,
    points: 20,
  },

  // SCP-1048
  {
    question: "What is SCP-1048 initially classified as before reclassification?",
    options: ["Euclid", "Safe", "Keter", "Thaumiel"],
    answer: 1,
    points: 20,
  },
  {
    question: "What is SCP-1048-A made of?",
    options: ["Metal scraps", "Human ears", "Teeth", "Fingernails"],
    answer: 1,
    points: 25,
  },
  {
    question: "Where is SCP-1048 contained?",
    options: ["Site-19", "Site-15", "Site-24", "Site-17"],
    answer: 2,
    points: 15,
  },

  // SCP-2399
  {
    question: "Where is SCP-2399 located?",
    options: ["Mars's atmosphere", "Jupiter's atmosphere", "Saturn's rings", "The Moon's surface"],
    answer: 1,
    points: 15,
  },
  {
    question: "What is the Great Red Spot of Jupiter according to SCP-2399's file?",
    options: ["A natural storm", "A spatial disruption caused by SCP-2399's weaponry", "An alien colony", "A portal to another dimension"],
    answer: 1,
    points: 25,
  },
  {
    question: "When was SCP-2399 visually discovered?",
    options: ["1945", "1963", "1977", "1989"],
    answer: 1,
    points: 20,
  },
  {
    question: "What galaxy does SCP-2399 receive communications from?",
    options: ["Andromeda Galaxy", "Milky Way", "Triangulum Galaxy", "Whirlpool Galaxy"],
    answer: 2,
    points: 30,
  },

  // SCP-500
  {
    question: "How many pills did SCP-500 originally contain?",
    options: ["12", "30", "47", "100"],
    answer: 2,
    points: 15,
  },
  {
    question: "What security clearance is required to access SCP-500?",
    options: ["Level 1", "Level 2", "Level 3", "Level 4"],
    answer: 3,
    points: 20,
  },
  {
    question: "How effective are duplicated SCP-500 pills from SCP-038?",
    options: ["100%", "75%", "50%", "30%"],
    answer: 3,
    points: 25,
  },

  // SCP-343
  {
    question: "Where was SCP-343 discovered?",
    options: ["London, England", "Berlin, Germany", "Prague, Czech Republic", "Rome, Italy"],
    answer: 2,
    points: 20,
  },
  {
    question: "What is SCP-343's containment site?",
    options: ["Site-19", "Site-15", "Site-17", "Site-24"],
    answer: 2,
    points: 15,
  },
  {
    question: "What is unusual about SCP-343's appearance?",
    options: ["It has no face", "Its features appear different to each observer", "It is invisible", "It constantly changes shape"],
    answer: 1,
    points: 20,
  },

  // SCP-939
  {
    question: "How do SCP-939 instances primarily lure prey?",
    options: ["By using pheromones", "By imitating human speech", "By mimicking human appearance", "By emitting light"],
    answer: 1,
    points: 15,
  },
  {
    question: "What class of amnestic do SCP-939 exhale?",
    options: ["Class A", "Class B", "Class C", "Class D"],
    answer: 2,
    points: 20,
  },
  {
    question: "What is the average height of SCP-939 instances?",
    options: ["1.5 meters", "1.8 meters", "2.2 meters", "2.8 meters"],
    answer: 2,
    points: 15,
  },
  {
    question: "What organ systems do SCP-939 lack?",
    options: ["Respiratory and digestive", "Nervous, circulatory, and digestive systems", "Skeletal and muscular", "Reproductive and endocrine"],
    answer: 1,
    points: 25,
  },
];
