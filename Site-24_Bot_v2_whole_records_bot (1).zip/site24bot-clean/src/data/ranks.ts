export interface Rank {
  title: string;
  emoji: string;
  minScore: number;
  color: number;
  description: string;
}

export const RANKS: Rank[] = [
  {
    title: "D-Class Personnel",
    emoji: "🟤",
    minScore: 0,
    color: 0x8b4513,
    description: "Expendable test subjects assigned to dangerous SCP experiments.",
  },
  {
    title: "Field Agent",
    emoji: "🟠",
    minScore: 100,
    color: 0xff8c00,
    description: "Foundation operatives deployed to investigate anomalous events.",
  },
  {
    title: "Junior Researcher",
    emoji: "🟡",
    minScore: 300,
    color: 0xffd700,
    description: "Entry-level scientific personnel assigned to Safe-class SCPs.",
  },
  {
    title: "Researcher",
    emoji: "🟢",
    minScore: 700,
    color: 0x32cd32,
    description: "Qualified Foundation scientists cleared for Euclid-class research.",
  },
  {
    title: "Senior Researcher",
    emoji: "🔵",
    minScore: 1500,
    color: 0x1e90ff,
    description: "Experienced researchers with access to Keter-class containment files.",
  },
  {
    title: "Site Director",
    emoji: "🟣",
    minScore: 3000,
    color: 0x9400d3,
    description: "Oversees all operations and containment at a Foundation facility.",
  },
  {
    title: "O5 Council Member",
    emoji: "⭐",
    minScore: 6000,
    color: 0xffd700,
    description: "One of the thirteen most powerful individuals in the Foundation. Clearance Level 5.",
  },
  {
    title: "Administrator",
    emoji: "👑",
    minScore: 12000,
    color: 0xff0000,
    description: "The supreme authority of the SCP Foundation. Above even the O5 Council.",
  },
];

export function getRank(score: number): Rank {
  // Find the highest rank the user qualifies for
  for (let i = RANKS.length - 1; i >= 0; i--) {
    if (score >= RANKS[i].minScore) {
      return RANKS[i];
    }
  }
  return RANKS[0];
}

export function getNextRank(score: number): Rank | null {
  for (let i = 0; i < RANKS.length; i++) {
    if (score < RANKS[i].minScore) {
      return RANKS[i];
    }
  }
  return null; // Already at max rank
}

export function getProgressToNextRank(score: number): {
  current: Rank;
  next: Rank | null;
  progress: number; // 0-100
  pointsNeeded: number;
} {
  const current = getRank(score);
  const next = getNextRank(score);

  if (!next) {
    return { current, next: null, progress: 100, pointsNeeded: 0 };
  }

  const rangeStart = current.minScore;
  const rangeEnd = next.minScore;
  const progress = Math.round(((score - rangeStart) / (rangeEnd - rangeStart)) * 100);
  const pointsNeeded = rangeEnd - score;

  return { current, next, progress, pointsNeeded };
}

export function buildProgressBar(progress: number, length = 10): string {
  const filled = Math.round((progress / 100) * length);
  const empty = length - filled;
  return "█".repeat(filled) + "░".repeat(empty);
}
