import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
} from "discord.js";
import { getUser, updateUser } from "../database.js";
import { SCP_LIST } from "../data/scps.js";
import { getRank, getNextRank, getProgressToNextRank, buildProgressBar } from "../data/ranks.js";

export const data = new SlashCommandBuilder()
  .setName("capture")
  .setDescription("Attempt to capture a random SCP entity! Uses 1 capture attempt.");

export async function execute(interaction: ChatInputCommandInteraction) {
  const user = getUser(interaction.user.id, interaction.user.username);

  if (user.captureAttempts <= 0) {
    const embed = new EmbedBuilder()
      .setColor(0xff0000)
      .setTitle("⚠️ No Capture Attempts Remaining")
      .setDescription(
        "You have no capture attempts left.\nUse `/daily` to claim **10 new attempts** at midnight UTC!"
      )
      .setFooter({ text: "Site-24 Bot" });
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  // Pick a random SCP
  const scp = SCP_LIST[Math.floor(Math.random() * SCP_LIST.length)];
  const alreadyCaptured = user.collection.includes(scp.id);
  const currentRank = getRank(user.quizScore);

  const classColors: Record<string, number> = {
    Safe: 0x00aa00,
    Euclid: 0xffaa00,
    Keter: 0xff0000,
    Thaumiel: 0x0000ff,
    Neutralized: 0x888888,
  };

  const previewEmbed = new EmbedBuilder()
    .setColor(classColors[scp.class] ?? 0x555555)
    .setTitle(`${scp.emoji} Anomaly Detected: ${scp.id}`)
    .setDescription(
      `**${scp.name}**\n*Class: ${scp.class}*\n\n${scp.description}\n\n` +
        `**Capture Probability:** ${scp.captureChance}%\n` +
        `**Reward:** ${scp.points} pts${alreadyCaptured ? " *(already in collection — 50% pts)*" : ""}\n\n` +
        `You have **${user.captureAttempts} attempt(s)** remaining.`
    )
    .addFields(
      { name: `${currentRank.emoji} Your Rank`, value: currentRank.title, inline: true },
      { name: "⭐ Score", value: `${user.quizScore} pts`, inline: true }
    )
    .setFooter({ text: "Site-24 Bot | You have 30s to decide" });

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("attempt_capture")
      .setLabel("🔒 Attempt Capture")
      .setStyle(ButtonStyle.Danger),
    new ButtonBuilder()
      .setCustomId("abort_capture")
      .setLabel("🚪 Abort")
      .setStyle(ButtonStyle.Secondary)
  );

  const reply = await interaction.reply({
    embeds: [previewEmbed],
    components: [row],
  });

  try {
    const buttonInteraction = await reply.awaitMessageComponent({
      filter: (i) => i.user.id === interaction.user.id,
      componentType: ComponentType.Button,
      time: 30_000,
    });

    // Deduct one attempt
    const freshUser = getUser(interaction.user.id, interaction.user.username);
    updateUser(interaction.user.id, {
      captureAttempts: Math.max(0, freshUser.captureAttempts - 1),
    });

    if (buttonInteraction.customId === "abort_capture") {
      const abortEmbed = new EmbedBuilder()
        .setColor(0x888888)
        .setTitle("🚪 Capture Aborted")
        .setDescription(`You retreated from ${scp.id}. **1 attempt was still used.**`)
        .setFooter({ text: `Remaining attempts: ${Math.max(0, freshUser.captureAttempts - 1)} | Site-24 Bot` });
      await buttonInteraction.update({ embeds: [abortEmbed], components: [] });
      return;
    }

    // Roll for capture
    const roll = Math.random() * 100;
    const success = roll < scp.captureChance;

    if (success) {
      const pointsEarned = alreadyCaptured ? Math.floor(scp.points * 0.5) : scp.points;
      const updatedUser = getUser(interaction.user.id, interaction.user.username);
      const newCollection = alreadyCaptured
        ? updatedUser.collection
        : [...updatedUser.collection, scp.id];
      const newScore = updatedUser.quizScore + pointsEarned;

      updateUser(interaction.user.id, {
        collection: newCollection,
        totalCaptures: updatedUser.totalCaptures + 1,
        quizScore: newScore,
      });

      // Check for rank-up
      const oldRank = getRank(updatedUser.quizScore);
      const newRank = getRank(newScore);
      const rankedUp = newRank.title !== oldRank.title;

      const { next, progress, pointsNeeded } = getProgressToNextRank(newScore);
      const bar = buildProgressBar(progress, 10);

      const successEmbed = new EmbedBuilder()
        .setColor(rankedUp ? newRank.color : 0x00ff00)
        .setTitle(rankedUp ? `🎉 RANK UP! ${newRank.emoji} ${newRank.title}` : `✅ Capture Successful — ${scp.id}`)
        .setDescription(
          rankedUp
            ? `**${scp.name}** secured AND you ranked up!\n\n` +
              `${oldRank.emoji} ~~${oldRank.title}~~ → ${newRank.emoji} **${newRank.title}**\n` +
              `*${newRank.description}*\n\n` +
              `**+${pointsEarned} points** | New score: **${newScore} pts**`
            : `**${scp.name}** has been secured!\n\n` +
              `${alreadyCaptured ? "*(Duplicate — 50% points)*\n" : ""}` +
              `**+${pointsEarned} points** added to your score.\n` +
              `Collection size: **${newCollection.length}** SCP(s)`
        )
        .addFields(
          { name: `${newRank.emoji} Rank`, value: newRank.title, inline: true },
          { name: "⭐ Score", value: `${newScore} pts`, inline: true },
          {
            name: next ? `📈 To ${next.emoji} ${next.title}` : "🏆 Max Rank",
            value: next ? `\`${bar}\` ${progress}% — ${pointsNeeded} pts away` : "Maximum rank achieved!",
            inline: false,
          }
        )
        .setFooter({
          text: `Remaining attempts: ${Math.max(0, freshUser.captureAttempts - 1)} | Roll: ${roll.toFixed(1)} | Site-24 Bot`,
        });

      await buttonInteraction.update({ embeds: [successEmbed], components: [] });
    } else {
      const { next, progress, pointsNeeded } = getProgressToNextRank(freshUser.quizScore);
      const bar = buildProgressBar(progress, 10);

      const failEmbed = new EmbedBuilder()
        .setColor(0xff4400)
        .setTitle(`❌ Capture Failed — ${scp.id} Escaped`)
        .setDescription(
          `**${scp.name}** broke containment!\n\n` +
            `The capture attempt failed. Better luck next time.\n` +
            `*(Roll: ${roll.toFixed(1)} — needed < ${scp.captureChance})*`
        )
        .addFields(
          { name: `${currentRank.emoji} Rank`, value: currentRank.title, inline: true },
          { name: "⭐ Score", value: `${freshUser.quizScore} pts`, inline: true },
          {
            name: next ? `📈 To ${next.emoji} ${next.title}` : "🏆 Max Rank",
            value: next ? `\`${bar}\` ${progress}% — ${pointsNeeded} pts away` : "Maximum rank achieved!",
            inline: false,
          }
        )
        .setFooter({
          text: `Remaining attempts: ${Math.max(0, freshUser.captureAttempts - 1)} | Site-24 Bot`,
        });
      await buttonInteraction.update({ embeds: [failEmbed], components: [] });
    }
  } catch {
    // Timeout
    const timeoutEmbed = new EmbedBuilder()
      .setColor(0x888888)
      .setTitle("⏱️ Capture Timed Out")
      .setDescription("No action taken. No attempts were used.")
      .setFooter({ text: "Site-24 Bot" });
    await interaction.editReply({ embeds: [timeoutEmbed], components: [] });
  }
}
