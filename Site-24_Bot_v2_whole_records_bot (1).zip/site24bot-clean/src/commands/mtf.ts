import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { MTF_LIST } from "../data/mtfs.js";

export const data = new SlashCommandBuilder()
  .setName("mtf")
  .setDescription("Look up information about a Mobile Task Force.")
  .addStringOption((opt) =>
    opt
      .setName("unit")
      .setDescription("The MTF designation or nickname")
      .setRequired(true)
      .addChoices(
        ...MTF_LIST.map((m) => ({
          name: `${m.designation} — "${m.nickname}"`,
          value: m.designation,
        }))
      )
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const designation = interaction.options.getString("unit", true);
  const mtf = MTF_LIST.find((m) => m.designation === designation);

  if (!mtf) {
    await interaction.reply({ content: "MTF not found.", ephemeral: true });
    return;
  }

  const commandColors: Record<string, number> = {
    "O5 Council": 0xff0000,
    "Foundation Command": 0x1e90ff,
    "Ethics Committee": 0x9400d3,
    "Foundation Tactical Command": 0xff6600,
  };

  const statusColors: Record<string, number> = {
    Active: 0x00aa00,
    Inactive: 0x888888,
    Classified: 0xff0000,
  };

  const color = commandColors[mtf.command] ?? statusColors[mtf.status] ?? 0x555555;

  // Truncate description for embed limits
  const desc = mtf.description.length > 1000
    ? mtf.description.slice(0, 997) + "..."
    : mtf.description;

  const personnelStr = mtf.personnel === 0 ? "**[CLASSIFIED]**" : `${mtf.personnel} personnel`;
  const missionsStr = mtf.missions === 0 ? "**[CLASSIFIED]**" : `${mtf.missions} recorded`;
  const notableStr = mtf.notableMissions.map((m) => `• ${m}`).join("\n");

  const embed = new EmbedBuilder()
    .setColor(color)
    .setTitle(`${mtf.emoji} ${mtf.designation} — "${mtf.nickname}"`)
    .addFields(
      { name: "🏛️ Command", value: mtf.command, inline: true },
      { name: "📍 Location", value: mtf.location, inline: true },
      { name: "🔐 Clearance Required", value: `Level ${mtf.clearanceLevel}`, inline: true },
      { name: "👥 Personnel", value: personnelStr, inline: true },
      { name: "📋 Missions", value: missionsStr, inline: true },
      { name: "🟢 Status", value: mtf.status, inline: true },
      { name: "🎯 Role", value: mtf.role },
      { name: "⚙️ Specialization", value: mtf.specialization },
      { name: "📖 Description", value: desc },
      { name: "🏅 Notable Missions", value: notableStr },
    )
    .setFooter({ text: "Site-24 Bot | Foundation Tactical Command" })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
