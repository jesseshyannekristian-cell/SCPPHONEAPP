import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
} from "discord.js";
import { getUser, updateUser } from "../database.js";
import { QUIZ_QUESTIONS } from "../data/quiz.js";
import { getRank, getNextRank, getProgressToNextRank, buildProgressBar } from "../data/ranks.js";

export const data = new SlashCommandBuilder()
  .setName("quiz")
  .setDescription("Answer an SCP trivia question to earn points!");

export async function execute(interaction: ChatInputCommandInteraction) {
  const user = getUser(interaction.user.id, interaction.user.username);

  // Pick a random question
  const q = QUIZ_QUESTIONS[Math.floor(Math.random() * QUIZ_QUESTIONS.length)];
  const currentRank = getRank(user.quizScore);

  // Build answer buttons (A B C D)
  const labels = ["A", "B", "C", "D"];
  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    q.options.map((opt, i) =>
      new ButtonBuilder()
        .setCustomId(`quiz_${i}`)
        .setLabel(`${labels[i]}: ${opt}`)
        .setStyle(ButtonStyle.Primary)
    )
  );

  const questionEmbed = new EmbedBuilder()
    .setColor(0x1e90ff)
    .setTitle("📝 SCP Foundation Trivia")
    .setDescription(`**${q.question}**`)
    .addFields(
      { name: `${currentRank.emoji} Your Rank`, value: currentRank.title, inline: true },
      { name: "⭐ Score", value: `${user.quizScore} pts`, inline: true },
      { name: "💰 Reward", value: `+${q.points} pts`, inline: true }
    )
    .setFooter({ text: "Site-24 Bot | You have 30s to answer" });

  const reply = await interaction.reply({
    embeds: [questionEmbed],
    components: [row],
  });

  try {
    const btn = await reply.awaitMessageComponent({
      filter: (i) => i.user.id === interaction.user.id,
      componentType: ComponentType.Button,
      time: 30_000,
    });

    const chosen = parseInt(btn.customId.replace("quiz_", ""), 10);
    const correct = chosen === q.answer;

    // Disable all buttons, highlight correct/wrong
    const resultRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
      q.options.map((opt, i) => {
        let style: ButtonStyle;
        if (i === q.answer) style = ButtonStyle.Success;
        else if (i === chosen && !correct) style = ButtonStyle.Danger;
        else style = ButtonStyle.Secondary;

        return new ButtonBuilder()
          .setCustomId(`quiz_result_${i}`)
          .setLabel(`${labels[i]}: ${opt}`)
          .setStyle(style)
          .setDisabled(true);
      })
    );

    if (correct) {
      const freshUser = getUser(interaction.user.id, interaction.user.username);
      const newScore = freshUser.quizScore + q.points;
      updateUser(interaction.user.id, { quizScore: newScore });

      const oldRank = getRank(freshUser.quizScore);
      const newRank = getRank(newScore);
      const rankedUp = newRank.title !== oldRank.title;

      const { next, progress, pointsNeeded } = getProgressToNextRank(newScore);
      const bar = buildProgressBar(progress, 10);

      const correctEmbed = new EmbedBuilder()
        .setColor(rankedUp ? newRank.color : 0x00cc66)
        .setTitle(rankedUp ? `🎉 RANK UP + Correct Answer!` : "✅ Correct!")
        .setDescription(
          rankedUp
            ? `**${q.options[q.answer]}** is right!\n\n` +
              `${oldRank.emoji} ~~${oldRank.title}~~ → ${newRank.emoji} **${newRank.title}**\n` +
              `*${newRank.description}*\n\n**+${q.points} pts** | New score: **${newScore} pts**`
            : `**${q.options[q.answer]}** is the correct answer!\n\n**+${q.points} pts** added to your score.`
        )
        .addFields(
          { name: `${newRank.emoji} Rank`, value: newRank.title, inline: true },
          { name: "⭐ Score", value: `${newScore} pts`, inline: true },
          {
            name: next ? `📈 To ${next.emoji} ${next.title}` : "🏆 Max Rank",
            value: next ? `\`${bar}\` ${progress}% — ${pointsNeeded} pts away` : "Maximum rank achieved!",
            inline: false,
          }
        )
        .setFooter({ text: "Site-24 Bot | Use /quiz again for another question" });

      await btn.update({ embeds: [correctEmbed], components: [resultRow] });
    } else {
      const wrongEmbed = new EmbedBuilder()
        .setColor(0xff4400)
        .setTitle("❌ Incorrect")
        .setDescription(
          `Wrong answer. The correct answer was:\n**${labels[q.answer]}: ${q.options[q.answer]}**\n\nNo points awarded.`
        )
        .addFields(
          { name: `${currentRank.emoji} Rank`, value: currentRank.title, inline: true },
          { name: "⭐ Score", value: `${user.quizScore} pts`, inline: true }
        )
        .setFooter({ text: "Site-24 Bot | Use /quiz to try again" });

      await btn.update({ embeds: [wrongEmbed], components: [resultRow] });
    }
  } catch {
    // Timeout
    const timedOutRow = new ActionRowBuilder<ButtonBuilder>().addComponents(
      q.options.map((opt, i) =>
        new ButtonBuilder()
          .setCustomId(`quiz_timeout_${i}`)
          .setLabel(`${labels[i]}: ${opt}`)
          .setStyle(i === q.answer ? ButtonStyle.Success : ButtonStyle.Secondary)
          .setDisabled(true)
      )
    );

    const timeoutEmbed = new EmbedBuilder()
      .setColor(0x888888)
      .setTitle("⏱️ Time's Up!")
      .setDescription(`You ran out of time.\nThe correct answer was: **${labels[q.answer]}: ${q.options[q.answer]}**`)
      .setFooter({ text: "Site-24 Bot" });

    await interaction.editReply({ embeds: [timeoutEmbed], components: [timedOutRow] });
  }
}
