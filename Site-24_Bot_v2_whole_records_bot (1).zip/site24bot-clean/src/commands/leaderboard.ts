import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getAllUsers } from "../database.js";
import { getRank } from "../data/ranks.js";

export const data = new SlashCommandBuilder()
  .setName("leaderboard")
  .setDescription("View the top SCP Foundation personnel by quiz score and captures.");

export async function execute(interaction: ChatInputCommandInteraction) {
  const users = getAllUsers();

  if (users.length === 0) {
    const embed = new EmbedBuilder()
      .setColor(0x555555)
      .setTitle("📊 Leaderboard — No Data Yet")
      .setDescription("No personnel have been registered yet. Be the first!")
      .setFooter({ text: "Site-24 Bot" });
    await interaction.reply({ embeds: [embed] });
    return;
  }

  // Sort by quiz score descending
  const sorted = [...users].sort((a, b) => b.quizScore - a.quizScore).slice(0, 10);

  const medals = ["🥇", "🥈", "🥉"];
  const rows = sorted.map((u, i) => {
    const medal = medals[i] ?? `**${i + 1}.**`;
    const rank = getRank(u.quizScore);
    return `${medal} ${rank.emoji} **${u.username}** — ${u.quizScore} pts | ${u.totalCaptures} captures\n   *${rank.title}*`;
  });

  const embed = new EmbedBuilder()
    .setColor(0xffd700)
    .setTitle("🏆 Site-24 Bot Leaderboard")
    .setDescription(rows.join("\n") || "No entries yet.")
    .addFields(
      {
        name: "📈 Total Personnel",
        value: `${users.length}`,
        inline: true,
      },
      {
        name: "🔒 Total Captures",
        value: `${users.reduce((acc, u) => acc + u.totalCaptures, 0)}`,
        inline: true,
      }
    )
    .setFooter({ text: "Site-24 Bot | Top 10 by Quiz Score" })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
