import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getUser, getAllUsers } from "../database.js";
import { SCP_LIST } from "../data/scps.js";
import { getProgressToNextRank, buildProgressBar } from "../data/ranks.js";

export const data = new SlashCommandBuilder()
  .setName("profile")
  .setDescription("View your SCP Foundation personnel dossier.")
  .addUserOption((opt) =>
    opt.setName("user").setDescription("View another user's profile").setRequired(false)
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const target = interaction.options.getUser("user") ?? interaction.user;
  const user = getUser(target.id, target.username);
  const allUsers = getAllUsers();

  // Calculate leaderboard rank
  const sorted = allUsers.sort((a, b) => b.quizScore - a.quizScore);
  const leaderboardPos = sorted.findIndex((u) => u.userId === user.userId) + 1;

  // Get rank info
  const { current, next, progress, pointsNeeded } = getProgressToNextRank(user.quizScore);
  const bar = buildProgressBar(progress, 12);

  // Get captured SCP names
  const capturedSCPs = SCP_LIST.filter((s) => user.collection.includes(s.id));
  const collectionText =
    capturedSCPs.length > 0
      ? capturedSCPs.map((s) => `${s.emoji} ${s.id}`).join(", ")
      : "*No SCPs captured yet*";

  const embed = new EmbedBuilder()
    .setColor(current.color)
    .setTitle(`📁 Personnel Dossier — ${target.username}`)
    .setThumbnail(target.displayAvatarURL())
    .addFields(
      { name: `${current.emoji} Rank`, value: current.title, inline: true },
      { name: "📊 Leaderboard", value: `#${leaderboardPos} of ${allUsers.length}`, inline: true },
      { name: "⭐ Quiz Score", value: `${user.quizScore} pts`, inline: true },
      { name: "🔒 Total Captures", value: `${user.totalCaptures}`, inline: true },
      { name: "📦 Collection", value: `${user.collection.length} SCP(s)`, inline: true },
      { name: "🎯 Attempts Left", value: `${user.captureAttempts}`, inline: true },
      {
        name: next
          ? `📈 Progress to ${next.emoji} ${next.title}`
          : "🏆 Maximum Rank Achieved",
        value: next
          ? `\`${bar}\` ${progress}%  —  **${pointsNeeded} pts** needed`
          : "You have reached the highest rank in the Foundation.",
      },
      {
        name: `🗂️ SCP Collection (${user.collection.length})`,
        value: collectionText.length > 1024 ? collectionText.substring(0, 1021) + "..." : collectionText,
      }
    )
    .setFooter({ text: `Site-24 Bot | Joined: ${new Date(user.joinedAt).toLocaleDateString()}` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
