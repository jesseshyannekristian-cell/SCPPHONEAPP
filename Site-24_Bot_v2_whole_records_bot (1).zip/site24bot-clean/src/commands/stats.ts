import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getAllUsers } from "../database.js";
import { SCP_LIST } from "../data/scps.js";

export const data = new SlashCommandBuilder()
  .setName("stats")
  .setDescription("View server-wide SCP Foundation statistics.");

export async function execute(interaction: ChatInputCommandInteraction) {
  const users = getAllUsers();

  if (users.length === 0) {
    const embed = new EmbedBuilder()
      .setColor(0x555555)
      .setTitle("📊 Site-24 Statistics — No Data")
      .setDescription("No personnel have been registered yet.")
      .setFooter({ text: "SCP Foundation — Site-24" });
    await interaction.reply({ embeds: [embed] });
    return;
  }

  const totalCaptures = users.reduce((acc, u) => acc + u.totalCaptures, 0);
  const totalScore = users.reduce((acc, u) => acc + u.quizScore, 0);
  const avgScore = Math.round(totalScore / users.length);

  // Most captured SCP
  const captureCount: Record<string, number> = {};
  for (const user of users) {
    for (const scpId of user.collection) {
      captureCount[scpId] = (captureCount[scpId] ?? 0) + 1;
    }
  }
  const mostCaptured = Object.entries(captureCount).sort((a, b) => b[1] - a[1])[0];
  const mostCapturedSCP = mostCaptured
    ? SCP_LIST.find((s) => s.id === mostCaptured[0])
    : null;

  const embed = new EmbedBuilder()
    .setColor(0x1e90ff)
    .setTitle("📊 SCP Foundation — Site-24 Statistics")
    .addFields(
      { name: "👥 Total Personnel", value: `${users.length}`, inline: true },
      { name: "🔒 Total Captures", value: `${totalCaptures}`, inline: true },
      { name: "⭐ Average Score", value: `${avgScore} pts`, inline: true },
      {
        name: "🏆 Top Scorer",
        value: users.sort((a, b) => b.quizScore - a.quizScore)[0]?.username ?? "N/A",
        inline: true,
      },
      {
        name: "🔒 Most Captured SCP",
        value: mostCapturedSCP
          ? `${mostCapturedSCP.emoji} ${mostCapturedSCP.id} (${mostCaptured[1]}x)`
          : "N/A",
        inline: true,
      },
      {
        name: "📦 Total SCPs Available",
        value: `${SCP_LIST.length}`,
        inline: true,
      }
    )
    .setFooter({ text: "SCP Foundation — Site-24" })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
