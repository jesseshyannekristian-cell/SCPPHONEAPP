import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getUser, updateUser, isNewDay, getTimeUntilReset } from "../database.js";

const DAILY_ATTEMPTS = 10;
const DAILY_BONUS_POINTS = 10;

export const data = new SlashCommandBuilder()
  .setName("daily")
  .setDescription("Claim your daily rewards: 10 capture attempts + 10 bonus quiz points!");

export async function execute(interaction: ChatInputCommandInteraction) {
  const user = getUser(interaction.user.id, interaction.user.username);

  if (!isNewDay(user.lastDailyClaim)) {
    const timeLeft = getTimeUntilReset();
    const embed = new EmbedBuilder()
      .setColor(0xff8800)
      .setTitle("⏳ Daily Already Claimed")
      .setDescription(
        `You have already claimed your daily reward today.\n\n` +
          `**Time until reset:** ${timeLeft}\n\n` +
          `Come back at **00:00 UTC** for your next reward!`
      )
      .setFooter({ text: "SCP Foundation — Site-24" });
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  // Grant rewards
  updateUser(interaction.user.id, {
    captureAttempts: DAILY_ATTEMPTS,
    quizScore: user.quizScore + DAILY_BONUS_POINTS,
    lastDailyClaim: new Date().toISOString(),
  });

  const embed = new EmbedBuilder()
    .setColor(0x00cc66)
    .setTitle("🎁 Daily Reward Claimed!")
    .setDescription(
      `Welcome back, **${interaction.user.username}**!\n\n` +
        `You have received:\n` +
        `> 🔒 **${DAILY_ATTEMPTS} Capture Attempts** — bypass the 3-minute cooldown\n` +
        `> ⭐ **+${DAILY_BONUS_POINTS} Bonus Quiz Points** — added to your score\n\n` +
        `Resets at **00:00 UTC** each day.\n` +
        `**Next reset in:** ${getTimeUntilReset()}`
    )
    .addFields(
      { name: "Total Quiz Score", value: `${user.quizScore + DAILY_BONUS_POINTS}`, inline: true },
      { name: "Capture Attempts", value: `${DAILY_ATTEMPTS}`, inline: true },
      { name: "Collection Size", value: `${user.collection.length} SCP(s)`, inline: true }
    )
    .setFooter({ text: "SCP Foundation — Site-24" })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
