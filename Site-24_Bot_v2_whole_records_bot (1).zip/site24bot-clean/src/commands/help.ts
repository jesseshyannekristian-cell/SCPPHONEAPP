import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("help")
  .setDescription("View all available Site-24 Bot commands.");

export async function execute(interaction: ChatInputCommandInteraction) {
  const embed = new EmbedBuilder()
    .setColor(0x1e90ff)
    .setTitle("📖 Site-24 Bot — Commands")
    .setDescription("Welcome, Foundation personnel. Here are all available commands:")
    .addFields(
      {
        name: "🎮 Game Commands",
        value: [
          "`/capture` — Attempt to capture a random SCP (uses 1 attempt)",
          "`/quiz` — Answer SCP trivia for points",
          "`/daily` — Claim daily: **10 capture attempts** + **10 bonus points**",
        ].join("\n"),
      },
      {
        name: "📊 Info Commands",
        value: [
          "`/profile [user]` — View your (or another user's) full personnel dossier",
          "`/collection` — View your captured SCP collection",
          "`/leaderboard` — Top 10 personnel by quiz score",
          "`/stats` — Server-wide Foundation statistics",
          "`/scpinfo <id>` — Look up a specific SCP entity",
          "`/scplist` — Browse all capturable SCP entities",
          "`/reports` — Open the Foundation Records archive",
        ].join("\n"),
      },
      {
        name: "🪖 MTF Commands",
        value: [
          "`/mtf <unit>` — Look up a Mobile Task Force dossier",
          "`/mtflist` — Browse all MTF units (paginated)",
          "`/mtfcompare <unit1> <unit2>` — Compare two MTFs side by side",
        ].join("\n"),
      },
      {
        name: "🔧 Utility Commands",
        value: [
          "`/site` — Link to the Site-24 Foundation database",
          "`/ping` — Check bot response time",
          "`/help` — Show this message",
        ].join("\n"),
      },
      {
        name: "ℹ️ How to Play",
        value: [
          "1. Use `/daily` every day to get **10 capture attempts**",
          "2. Use `/capture` to attempt capturing SCPs and earn points",
          "3. Use `/quiz` to answer trivia questions for bonus points",
          "4. Check `/leaderboard` to see how you rank among Foundation personnel",
          "5. Build your SCP `/collection` — rarer SCPs are worth more!",
        ].join("\n"),
      },
      {
        name: "🏅 Rank Ladder",
        value: [
          "🟤 D-Class Personnel — 0 pts",
          "🟠 Field Agent — 100 pts",
          "🟡 Junior Researcher — 300 pts",
          "🟢 Researcher — 700 pts",
          "🔵 Senior Researcher — 1,500 pts",
          "🟣 Site Director — 3,000 pts",
          "⭐ O5 Council Member — 6,000 pts",
          "👑 Administrator — 12,000 pts",
        ].join("\n"),
      }
    )
    .setFooter({ text: "Site-24 Bot | Secure. Contain. Protect." });

  await interaction.reply({ embeds: [embed] });
}
