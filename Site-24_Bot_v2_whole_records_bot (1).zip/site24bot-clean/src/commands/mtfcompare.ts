import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { MTF_LIST } from "../data/mtfs.js";

const choices = MTF_LIST.map((m) => ({
  name: `${m.designation} — "${m.nickname}"`,
  value: m.designation,
}));

export const data = new SlashCommandBuilder()
  .setName("mtfcompare")
  .setDescription("Compare two Mobile Task Forces side by side.")
  .addStringOption((opt) =>
    opt
      .setName("unit1")
      .setDescription("First MTF to compare")
      .setRequired(true)
      .addChoices(...choices)
  )
  .addStringOption((opt) =>
    opt
      .setName("unit2")
      .setDescription("Second MTF to compare")
      .setRequired(true)
      .addChoices(...choices)
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const d1 = interaction.options.getString("unit1", true);
  const d2 = interaction.options.getString("unit2", true);

  if (d1 === d2) {
    await interaction.reply({ content: "⚠️ Please select two **different** MTFs to compare.", ephemeral: true });
    return;
  }

  const a = MTF_LIST.find((m) => m.designation === d1)!;
  const b = MTF_LIST.find((m) => m.designation === d2)!;

  const fmt = (val: number | string, isClassified: boolean) =>
    isClassified ? "**[CLASSIFIED]**" : String(val);

  const personnelA = a.personnel === 0 ? "**[CLASSIFIED]**" : `${a.personnel}`;
  const personnelB = b.personnel === 0 ? "**[CLASSIFIED]**" : `${b.personnel}`;
  const missionsA = a.missions === 0 ? "**[CLASSIFIED]**" : `${a.missions}`;
  const missionsB = b.missions === 0 ? "**[CLASSIFIED]**" : `${b.missions}`;

  const statusIcon = (s: string) => s === "Active" ? "🟢" : s === "Inactive" ? "🔴" : "⚫";

  // Truncate specialization to keep embed tidy
  const specA = a.specialization.length > 120 ? a.specialization.slice(0, 117) + "..." : a.specialization;
  const specB = b.specialization.length > 120 ? b.specialization.slice(0, 117) + "..." : b.specialization;

  const embed = new EmbedBuilder()
    .setColor(0x2b2d31)
    .setTitle(`⚔️ MTF Comparison`)
    .setDescription(`**${a.emoji} ${a.designation}** vs **${b.emoji} ${b.designation}**`)
    .addFields(
      // Row: Nickname
      { name: `${a.emoji} ${a.designation}`, value: `"${a.nickname}"`, inline: true },
      { name: "\u200b", value: "\u200b", inline: true },
      { name: `${b.emoji} ${b.designation}`, value: `"${b.nickname}"`, inline: true },

      // Row: Status
      { name: "🟢 Status", value: `${statusIcon(a.status)} ${a.status}`, inline: true },
      { name: "\u200b", value: "vs", inline: true },
      { name: "🟢 Status", value: `${statusIcon(b.status)} ${b.status}`, inline: true },

      // Row: Clearance
      { name: "🔐 Clearance", value: `Level ${a.clearanceLevel}`, inline: true },
      { name: "\u200b", value: "vs", inline: true },
      { name: "🔐 Clearance", value: `Level ${b.clearanceLevel}`, inline: true },

      // Row: Personnel
      { name: "👥 Personnel", value: personnelA, inline: true },
      { name: "\u200b", value: "vs", inline: true },
      { name: "👥 Personnel", value: personnelB, inline: true },

      // Row: Missions
      { name: "📋 Missions", value: missionsA, inline: true },
      { name: "\u200b", value: "vs", inline: true },
      { name: "📋 Missions", value: missionsB, inline: true },

      // Row: Command
      { name: "🏛️ Command", value: a.command, inline: true },
      { name: "\u200b", value: "vs", inline: true },
      { name: "🏛️ Command", value: b.command, inline: true },

      // Row: Location
      { name: "📍 Location", value: a.location, inline: true },
      { name: "\u200b", value: "vs", inline: true },
      { name: "📍 Location", value: b.location, inline: true },

      // Full-width: Role
      { name: `⚙️ ${a.designation} — Role`, value: a.role, inline: false },
      { name: `⚙️ ${b.designation} — Role`, value: b.role, inline: false },

      // Full-width: Specialization
      { name: `🎯 ${a.designation} — Specialization`, value: specA, inline: false },
      { name: `🎯 ${b.designation} — Specialization`, value: specB, inline: false },
    )
    .setFooter({ text: "Site-24 Bot | Use /mtf to view a full unit dossier" })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
