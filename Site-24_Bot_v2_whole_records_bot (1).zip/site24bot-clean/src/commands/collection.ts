import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { getUser } from "../database.js";
import { SCP_LIST } from "../data/scps.js";

export const data = new SlashCommandBuilder()
  .setName("collection")
  .setDescription("View your captured SCP collection.");

export async function execute(interaction: ChatInputCommandInteraction) {
  const user = getUser(interaction.user.id, interaction.user.username);

  if (user.collection.length === 0) {
    const embed = new EmbedBuilder()
      .setColor(0x555555)
      .setTitle("🗂️ Your SCP Collection — Empty")
      .setDescription(
        "You haven't captured any SCPs yet!\nUse `/capture` to start building your collection."
      )
      .setFooter({ text: "SCP Foundation — Site-24" });
    await interaction.reply({ embeds: [embed], ephemeral: true });
    return;
  }

  const capturedSCPs = SCP_LIST.filter((s) => user.collection.includes(s.id));
  const totalPossible = SCP_LIST.length;
  const completionPct = Math.round((user.collection.length / totalPossible) * 100);

  const classColors: Record<string, number> = {
    Safe: 0x00aa00,
    Euclid: 0xffaa00,
    Keter: 0xff0000,
    Thaumiel: 0x0000ff,
    Neutralized: 0x888888,
  };

  const byClass: Record<string, typeof capturedSCPs> = {};
  for (const scp of capturedSCPs) {
    if (!byClass[scp.class]) byClass[scp.class] = [];
    byClass[scp.class].push(scp);
  }

  const embed = new EmbedBuilder()
    .setColor(0x2f4f4f)
    .setTitle(`🗂️ ${interaction.user.username}'s SCP Collection`)
    .setDescription(
      `**${user.collection.length}/${totalPossible}** SCPs captured (${completionPct}% complete)`
    );

  for (const [cls, scps] of Object.entries(byClass)) {
    embed.addFields({
      name: `${cls} Class (${scps.length})`,
      value: scps.map((s) => `${s.emoji} ${s.id} — ${s.name}`).join("\n"),
    });
  }

  embed.setFooter({ text: "SCP Foundation — Site-24" }).setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
