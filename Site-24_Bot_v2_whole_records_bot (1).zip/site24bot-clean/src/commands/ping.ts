import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("ping")
  .setDescription("Check the bot's response time.");

export async function execute(interaction: ChatInputCommandInteraction) {
  const sent = await interaction.reply({ content: "Pinging...", fetchReply: true });
  const latency = sent.createdTimestamp - interaction.createdTimestamp;
  const wsLatency = interaction.client.ws.ping;

  const embed = new EmbedBuilder()
    .setColor(0x00cc66)
    .setTitle("🏓 Pong!")
    .addFields(
      { name: "Roundtrip Latency", value: `${latency}ms`, inline: true },
      { name: "WebSocket Heartbeat", value: `${wsLatency}ms`, inline: true }
    )
    .setFooter({ text: "SCP Foundation — Site-24" });

  await interaction.editReply({ content: "", embeds: [embed] });
}
