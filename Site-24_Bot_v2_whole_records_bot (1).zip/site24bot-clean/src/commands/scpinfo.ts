import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { SCP_LIST } from "../data/scps.js";

export const data = new SlashCommandBuilder()
  .setName("scpinfo")
  .setDescription("Look up detailed information about a specific SCP from the wiki.")
  .addStringOption((opt) =>
    opt
      .setName("id")
      .setDescription("The SCP ID (e.g. SCP-173)")
      .setRequired(true)
      .addChoices(...SCP_LIST.map((s) => ({ name: `${s.id} — ${s.name}`, value: s.id })))
  );

export async function execute(interaction: ChatInputCommandInteraction) {
  const id = interaction.options.getString("id", true);
  const scp = SCP_LIST.find((s) => s.id === id);

  if (!scp) {
    await interaction.reply({ content: "SCP not found.", ephemeral: true });
    return;
  }

  const classColors: Record<string, number> = {
    Safe: 0x00aa00,
    Euclid: 0xffaa00,
    Keter: 0xff0000,
    Thaumiel: 0x0000ff,
    Neutralized: 0x888888,
  };

  const behaviorsText = scp.behaviors.map((b) => `• ${b}`).join("\n");

  // Truncate description and containment procedures to fit Discord embed limits
  const desc = scp.description.length > 900
    ? scp.description.slice(0, 897) + "..."
    : scp.description;

  const containment = scp.containmentProcedures.length > 900
    ? scp.containmentProcedures.slice(0, 897) + "..."
    : scp.containmentProcedures;

  const embed = new EmbedBuilder()
    .setColor(classColors[scp.class] ?? 0x555555)
    .setTitle(`${scp.emoji} ${scp.id} — ${scp.name}`)
    .setURL(scp.wikiUrl)
    .addFields(
      { name: "🔖 Object Class", value: scp.class, inline: true },
      { name: "📍 Containment Site", value: scp.containmentSite, inline: true },
      { name: "🎯 Capture Chance", value: `${scp.captureChance}%`, inline: true },
      { name: "💰 Point Value", value: `${scp.points} pts`, inline: true },
      { name: "📄 Description", value: desc },
      { name: "🔒 Special Containment Procedures", value: containment },
      { name: "⚠️ Known Behaviors & Abilities", value: behaviorsText },
    )
    .setFooter({ text: `Site-24 Bot | Source: SCP Wiki` })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
