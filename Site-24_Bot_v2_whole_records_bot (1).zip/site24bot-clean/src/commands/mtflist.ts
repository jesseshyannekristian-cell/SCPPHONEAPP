import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ComponentType,
} from "discord.js";
import { MTF_LIST } from "../data/mtfs.js";

const PAGE_SIZE = 5;

function buildPage(page: number): EmbedBuilder {
  const totalPages = Math.ceil(MTF_LIST.length / PAGE_SIZE);
  const start = page * PAGE_SIZE;
  const slice = MTF_LIST.slice(start, start + PAGE_SIZE);

  const lines = slice.map((mtf) => {
    const statusIcon = mtf.status === "Active" ? "🟢" : mtf.status === "Inactive" ? "🔴" : "⚫";
    const personnelStr = mtf.personnel === 0 ? "[CLASSIFIED]" : `${mtf.personnel} personnel`;
    return (
      `${mtf.emoji} **${mtf.designation}** — "${mtf.nickname}"\n` +
      `> ${statusIcon} ${mtf.status} | 🔐 Clearance ${mtf.clearanceLevel} | 👥 ${personnelStr}\n` +
      `> *${mtf.role.length > 90 ? mtf.role.slice(0, 87) + "..." : mtf.role}*`
    );
  });

  return new EmbedBuilder()
    .setColor(0x1a1a2e)
    .setTitle("📁 Foundation MTF Database — All Units")
    .setDescription(
      `**${MTF_LIST.length} Mobile Task Forces** on record.\nUse \`/mtf\` to view a unit's full dossier.\n\n` +
        lines.join("\n\n")
    )
    .setFooter({ text: `Page ${page + 1} of ${totalPages} | Site-24 Bot | SECURE. CONTAIN. PROTECT.` })
    .setTimestamp();
}

function buildRow(page: number, disabled = false): ActionRowBuilder<ButtonBuilder> {
  const totalPages = Math.ceil(MTF_LIST.length / PAGE_SIZE);
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId("mtflist_prev")
      .setLabel("◀ Previous")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(disabled || page === 0),
    new ButtonBuilder()
      .setCustomId("mtflist_page")
      .setLabel(`${page + 1} / ${totalPages}`)
      .setStyle(ButtonStyle.Primary)
      .setDisabled(true),
    new ButtonBuilder()
      .setCustomId("mtflist_next")
      .setLabel("Next ▶")
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(disabled || page >= totalPages - 1)
  );
}

export const data = new SlashCommandBuilder()
  .setName("mtflist")
  .setDescription("Browse the full Foundation Mobile Task Force database.");

export async function execute(interaction: ChatInputCommandInteraction) {
  let page = 0;

  const reply = await interaction.reply({
    embeds: [buildPage(page)],
    components: [buildRow(page)],
  });

  const collector = reply.createMessageComponentCollector({
    componentType: ComponentType.Button,
    filter: (i) => i.user.id === interaction.user.id,
    time: 120_000,
  });

  collector.on("collect", async (btn) => {
    if (btn.customId === "mtflist_next") page++;
    else if (btn.customId === "mtflist_prev") page--;

    await btn.update({
      embeds: [buildPage(page)],
      components: [buildRow(page)],
    });
  });

  collector.on("end", async () => {
    try {
      await interaction.editReply({
        components: [buildRow(page, true)],
      });
    } catch {
      // Message may have been deleted
    }
  });
}
