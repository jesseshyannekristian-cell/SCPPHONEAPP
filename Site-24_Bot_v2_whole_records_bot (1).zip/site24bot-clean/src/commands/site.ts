import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";

export const data = new SlashCommandBuilder()
  .setName("site")
  .setDescription("Access the Site-24 Foundation database archive.");

export async function execute(interaction: ChatInputCommandInteraction) {
  const embed = new EmbedBuilder()
    .setColor(0x1a1a2e)
    .setTitle("🏛️ Site-24 Foundation Database Archive")
    .setURL("https://site24db-3mphm7jv.manus.space/")
    .setDescription(
      "Access the official **Site-24 Foundation Database** for SCP records, MTF dossiers, and classified personnel files.\n\n" +
      "🔗 **[Click here to open the database](https://site24db-3mphm7jv.manus.space/)**"
    )
    .addFields(
      { name: "📁 Contents", value: "SCP Object Files • MTF Unit Dossiers • Containment Procedures", inline: false },
      { name: "🔐 Access Level", value: "Level 3 Clearance Required", inline: true },
      { name: "📡 Status", value: "🟢 Online", inline: true }
    )
    .setFooter({ text: "Site-24 Bot | SECURE. CONTAIN. PROTECT." })
    .setTimestamp();

  await interaction.reply({ embeds: [embed] });
}
