import {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonInteraction,
  ButtonStyle,
  ChatInputCommandInteraction,
  EmbedBuilder,
  Interaction,
  ModalBuilder,
  ModalSubmitInteraction,
  SlashCommandBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuInteraction,
  TextInputBuilder,
  TextInputStyle,
} from "discord.js";
import {
  createArchiveDocument,
  getRecentArchiveDocuments,
  searchArchiveDocuments,
  type ArchiveCategory,
  type ArchiveDocument,
} from "../database.js";

type Action = "create" | "browse" | "search";

type CategoryInfo = {
  label: string;
  shortLabel: string;
  emoji: string;
  color: number;
  prefix: string;
  template: string[];
};

const CATEGORIES: Record<ArchiveCategory, CategoryInfo> = {
  incident: {
    label: "Incident Reports",
    shortLabel: "Incident",
    emoji: "🚨",
    color: 0xff3b30,
    prefix: "IR",
    template: [
      "Incident Number",
      "Date & Time",
      "Site / Area",
      "Personnel Involved",
      "SCPs Involved",
      "Incident Summary",
      "Chronological Timeline",
      "Casualties",
      "Containment Actions",
      "Resolution",
      "Recommendations",
      "Attached Evidence",
    ],
  },
  brief: {
    label: "Briefs",
    shortLabel: "Brief",
    emoji: "📝",
    color: 0x1e90ff,
    prefix: "BR",
    template: [
      "Brief Number",
      "Subject",
      "Objective",
      "Executive Summary",
      "Assigned Departments",
      "Assigned Personnel",
      "Threat Level",
      "Mission Notes",
      "Attachments",
    ],
  },
  anomaly: {
    label: "Anomaly Assessments",
    shortLabel: "Assessment",
    emoji: "🔬",
    color: 0xb14cff,
    prefix: "AA",
    template: [
      "Assessment ID",
      "Related SCP",
      "Threat Rating",
      "Risk Analysis",
      "Behavioral Analysis",
      "Containment Review",
      "Recommended Procedure Changes",
      "Research Notes",
    ],
  },
  mtf: {
    label: "MTF Dossiers",
    shortLabel: "MTF",
    emoji: "🛡️",
    color: 0x2ecc71,
    prefix: "MTF",
    template: [
      "MTF Designation",
      "Nickname",
      "Commander",
      "Assigned Site",
      "Mission Profile",
      "Operational Status",
      "Personnel Roster",
      "Equipment",
      "Assigned SCPs",
      "Operational History",
      "Deployment Logs",
    ],
  },
  personnel: {
    label: "Personnel Dossiers",
    shortLabel: "Personnel",
    emoji: "👤",
    color: 0xf1c40f,
    prefix: "PD",
    template: [
      "Personnel ID",
      "Name",
      "Photograph",
      "Rank",
      "Department",
      "Clearance Level",
      "Current Assignment",
      "Service History",
      "Psychological Evaluation",
      "Commendations",
      "Disciplinary Actions",
      "Notes",
    ],
  },
  scp: {
    label: "SCP Dossiers",
    shortLabel: "SCP",
    emoji: "☣️",
    color: 0xe74c3c,
    prefix: "SCP",
    template: [
      "SCP Number",
      "Object Class",
      "Containment Class",
      "Risk Class",
      "Disruption Class",
      "Assigned Site",
      "Assigned MTF",
      "Discovery Location",
      "Special Containment Procedures",
      "Description",
      "Recovery Log",
      "Testing Log",
      "Incident Log",
      "Addenda",
      "Images",
    ],
  },
};

const categoryChoices = Object.entries(CATEGORIES).map(([value, info]) => ({
  name: `${info.emoji} ${info.label}`,
  value,
}));

export const data = new SlashCommandBuilder()
  .setName("reports")
  .setDescription("Open the Site-24 Foundation Records archive.")
  .addStringOption((opt) =>
    opt
      .setName("category")
      .setDescription("Archive category")
      .setRequired(false)
      .addChoices(...categoryChoices)
  )
  .addStringOption((opt) =>
    opt
      .setName("action")
      .setDescription("What to do in the archive")
      .setRequired(false)
      .addChoices(
        { name: "➕ Create", value: "create" },
        { name: "📖 Browse", value: "browse" },
        { name: "🔍 Search", value: "search" }
      )
  )
  .addStringOption((opt) =>
    opt
      .setName("title")
      .setDescription("Document title when creating a record")
      .setRequired(false)
      .setMaxLength(120)
  )
  .addStringOption((opt) =>
    opt
      .setName("content")
      .setDescription("Document content, summary, or notes when creating a record")
      .setRequired(false)
      .setMaxLength(1500)
  )
  .addStringOption((opt) =>
    opt
      .setName("query")
      .setDescription("Search terms for archived records")
      .setRequired(false)
      .setMaxLength(100)
  );

function categoryMenu(selected?: ArchiveCategory) {
  return new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId("records_category")
      .setPlaceholder("📂 Choose an archive section")
      .addOptions(
        Object.entries(CATEGORIES).map(([value, info]) => ({
          label: info.label,
          value,
          emoji: info.emoji,
          description: `Create, browse, or search ${info.label}`,
          default: selected === value,
        }))
      )
  );
}

function actionButtons(category: ArchiveCategory) {
  return new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`records_create_${category}`)
      .setLabel("Create")
      .setEmoji("➕")
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId(`records_browse_${category}`)
      .setLabel("Browse")
      .setEmoji("📖")
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId(`records_search_${category}`)
      .setLabel("Search")
      .setEmoji("🔍")
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId("records_home")
      .setLabel("Reports Home")
      .setEmoji("📂")
      .setStyle(ButtonStyle.Secondary)
  );
}

function buildHubEmbed() {
  return new EmbedBuilder()
    .setColor(0x111111)
    .setTitle("📂 Site-24 Reports — 🗄️ Foundation Archive")
    .setDescription(
      [
        "Secure Foundation records terminal initialized.",
        "Every record type lives inside one Archive section with **Create**, **Browse**, and **Search**. No duplicate tabs.",
        "",
        "Pick a section from the dropdown, or use `/reports category:<type> action:<action>`.",
      ].join("\n")
    )
    .addFields(
      { name: "🚨 Incident Reports", value: "➕ Create • 📖 Browse • 🔍 Search", inline: true },
      { name: "📝 Briefs", value: "➕ Create • 📖 Browse • 🔍 Search", inline: true },
      { name: "🔬 Anomaly Assessments", value: "➕ Create • 📖 Browse • 🔍 Search", inline: true },
      { name: "🛡️ MTF Dossiers", value: "➕ Create • 📖 Browse • 🔍 Search", inline: true },
      { name: "👤 Personnel Dossiers", value: "➕ Create • 📖 Browse • 🔍 Search", inline: true },
      { name: "☣️ SCP Dossiers", value: "➕ Create • 📖 Browse • 🔍 Search", inline: true }
    )
    .setFooter({ text: "Site-24 Records System | SECURE. CONTAIN. PROTECT." })
    .setTimestamp();
}

function buildCategoryEmbed(category: ArchiveCategory) {
  const info = CATEGORIES[category];
  return new EmbedBuilder()
    .setColor(info.color)
    .setTitle(`${info.emoji} ${info.label}`)
    .setDescription("Select an action below to create a new record, browse recent records, or search this archive section.")
    .addFields(
      { name: "➕ Create", value: `Open a form and save a new ${info.shortLabel} record.`, inline: true },
      { name: "📖 Browse", value: "Show the newest archived records.", inline: true },
      { name: "🔍 Search", value: "Find records by title, ID, or content.", inline: true },
      { name: "📋 Suggested Fields", value: info.template.map((field) => `• ${field}`).join("\n").slice(0, 1024), inline: false }
    )
    .setFooter({ text: `Archive prefix: ${info.prefix} | Site-24 Records System` })
    .setTimestamp();
}

function buildTemplate(category: ArchiveCategory) {
  const info = CATEGORIES[category];
  return new EmbedBuilder()
    .setColor(info.color)
    .setTitle(`${info.emoji} Create ${info.label}`)
    .setDescription(
      [
        "Use the button menu, or save directly with:",
        "`/reports category:<type> action:Create title:<title> content:<report text>`",
        "",
        "Suggested Foundation fields:",
      ].join("\n")
    )
    .addFields({ name: "📋 Template", value: info.template.map((field) => `• ${field}`).join("\n").slice(0, 1024) })
    .setFooter({ text: "Created records are stored in the Site-24 archive database." })
    .setTimestamp();
}

function formatDocumentList(docs: ArchiveDocument[]) {
  if (docs.length === 0) return "No archived records found for this section yet.";
  return docs
    .map((doc) => {
      const preview = doc.content.length > 140 ? `${doc.content.slice(0, 137)}...` : doc.content;
      return `**${doc.documentId}** — ${doc.title}\n👤 ${doc.authorName} • 📌 ${doc.status} • 📅 ${new Date(doc.createdAt).toLocaleString()}\n${preview}`;
    })
    .join("\n\n")
    .slice(0, 3800);
}

function buildListEmbed(category: ArchiveCategory, docs: ArchiveDocument[], titlePrefix: string, query?: string) {
  const info = CATEGORIES[category];
  const embed = new EmbedBuilder()
    .setColor(info.color)
    .setTitle(`${info.emoji} ${titlePrefix} ${info.label}`)
    .setDescription(formatDocumentList(docs))
    .setFooter({ text: "Site-24 Records System | Archive terminal" })
    .setTimestamp();
  if (query) embed.addFields({ name: "🔍 Query", value: query, inline: false });
  return embed;
}

function buildCreateModal(category: ArchiveCategory) {
  const info = CATEGORIES[category];
  const modal = new ModalBuilder()
    .setCustomId(`records_modal_create_${category}`)
    .setTitle(`Create ${info.shortLabel} Record`);

  const titleInput = new TextInputBuilder()
    .setCustomId("title")
    .setLabel("Document title")
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(120)
    .setPlaceholder("Example: Sector-20 Breach Response");

  const classificationInput = new TextInputBuilder()
    .setCustomId("classification")
    .setLabel("Classification / Clearance")
    .setStyle(TextInputStyle.Short)
    .setRequired(false)
    .setMaxLength(100)
    .setPlaceholder("Example: Level 3 | Confidential | Site-20");

  const contentInput = new TextInputBuilder()
    .setCustomId("content")
    .setLabel("Report content")
    .setStyle(TextInputStyle.Paragraph)
    .setRequired(true)
    .setMaxLength(3500)
    .setPlaceholder("Paste the report text here. Include Foundation fields as needed.");

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(titleInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(classificationInput),
    new ActionRowBuilder<TextInputBuilder>().addComponents(contentInput)
  );
  return modal;
}

function buildSearchModal(category: ArchiveCategory) {
  const info = CATEGORIES[category];
  const modal = new ModalBuilder()
    .setCustomId(`records_modal_search_${category}`)
    .setTitle(`Search ${info.shortLabel} Archive`);

  const queryInput = new TextInputBuilder()
    .setCustomId("query")
    .setLabel("Search title, document ID, or content")
    .setStyle(TextInputStyle.Short)
    .setRequired(true)
    .setMaxLength(100)
    .setPlaceholder("Example: breach, Gunz, SCP-16829, Level 5");

  modal.addComponents(new ActionRowBuilder<TextInputBuilder>().addComponents(queryInput));
  return modal;
}

function parseCategory(value: string | null): ArchiveCategory | null {
  if (!value) return null;
  return Object.prototype.hasOwnProperty.call(CATEGORIES, value) ? (value as ArchiveCategory) : null;
}

export async function execute(interaction: ChatInputCommandInteraction) {
  const category = parseCategory(interaction.options.getString("category"));
  const action = interaction.options.getString("action") as Action | null;
  const title = interaction.options.getString("title");
  const content = interaction.options.getString("content");
  const query = interaction.options.getString("query");

  if (!category && !action) {
    await interaction.reply({ embeds: [buildHubEmbed()], components: [categoryMenu()] });
    return;
  }

  if (!category) {
    await interaction.reply({ content: "⚠️ Select an archive category first.", ephemeral: true });
    return;
  }

  const info = CATEGORIES[category];

  if (!action) {
    await interaction.reply({ embeds: [buildCategoryEmbed(category)], components: [categoryMenu(category), actionButtons(category)] });
    return;
  }

  if (action === "create") {
    if (!title || !content) {
      await interaction.reply({ embeds: [buildTemplate(category)], components: [actionButtons(category)], ephemeral: true });
      return;
    }

    const doc = createArchiveDocument({
      category,
      title,
      content,
      authorId: interaction.user.id,
      authorName: interaction.user.tag,
    });

    const embed = new EmbedBuilder()
      .setColor(info.color)
      .setTitle(`${info.emoji} Archived: ${doc.documentId}`)
      .setDescription(`**${doc.title}** has been saved to **${info.label}**.`)
      .addFields(
        { name: "📂 Category", value: `${info.emoji} ${info.label}`, inline: true },
        { name: "👤 Author", value: interaction.user.tag, inline: true },
        { name: "📌 Status", value: "Archived", inline: true },
        { name: "📄 Content", value: content.length > 1000 ? `${content.slice(0, 997)}...` : content }
      )
      .setFooter({ text: "Site-24 Records System | Document secured." })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], components: [actionButtons(category)] });
    return;
  }

  if (action === "browse") {
    const docs = getRecentArchiveDocuments(category, 8);
    await interaction.reply({ embeds: [buildListEmbed(category, docs, "Browse")], components: [actionButtons(category)] });
    return;
  }

  if (action === "search") {
    if (!query) {
      await interaction.reply({ content: "🔍 Add a `query` to search this archive section.", ephemeral: true });
      return;
    }

    const docs = searchArchiveDocuments(category, query, 8);
    await interaction.reply({ embeds: [buildListEmbed(category, docs, "Search", query)], components: [actionButtons(category)] });
  }
}

async function handleCategorySelect(interaction: StringSelectMenuInteraction) {
  const category = parseCategory(interaction.values[0]);
  if (!category) {
    await interaction.reply({ content: "⚠️ Unknown archive category.", ephemeral: true });
    return;
  }

  await interaction.update({ embeds: [buildCategoryEmbed(category)], components: [categoryMenu(category), actionButtons(category)] });
}

async function handleButton(interaction: ButtonInteraction) {
  const customId = interaction.customId;

  if (customId === "records_home") {
    await interaction.update({ embeds: [buildHubEmbed()], components: [categoryMenu()] });
    return;
  }

  const match = customId.match(/^records_(create|browse|search)_(incident|brief|anomaly|mtf|personnel|scp)$/);
  if (!match) return;

  const action = match[1] as Action;
  const category = match[2] as ArchiveCategory;

  if (action === "create") {
    await interaction.showModal(buildCreateModal(category));
    return;
  }

  if (action === "browse") {
    const docs = getRecentArchiveDocuments(category, 8);
    await interaction.update({ embeds: [buildListEmbed(category, docs, "Browse")], components: [categoryMenu(category), actionButtons(category)] });
    return;
  }

  if (action === "search") {
    await interaction.showModal(buildSearchModal(category));
  }
}

async function handleModal(interaction: ModalSubmitInteraction) {
  const createMatch = interaction.customId.match(/^records_modal_create_(incident|brief|anomaly|mtf|personnel|scp)$/);
  if (createMatch) {
    const category = createMatch[1] as ArchiveCategory;
    const info = CATEGORIES[category];
    const title = interaction.fields.getTextInputValue("title");
    const classification = interaction.fields.getTextInputValue("classification") || "Unclassified";
    const reportContent = interaction.fields.getTextInputValue("content");
    const content = `Classification: ${classification}\n\n${reportContent}`;
    const doc = createArchiveDocument({
      category,
      title,
      content,
      authorId: interaction.user.id,
      authorName: interaction.user.tag,
    });

    const embed = new EmbedBuilder()
      .setColor(info.color)
      .setTitle(`${info.emoji} Archived: ${doc.documentId}`)
      .setDescription(`**${doc.title}** has been saved to **${info.label}**.`)
      .addFields(
        { name: "📂 Category", value: `${info.emoji} ${info.label}`, inline: true },
        { name: "👤 Author", value: interaction.user.tag, inline: true },
        { name: "🔐 Classification", value: classification, inline: true },
        { name: "📄 Preview", value: reportContent.length > 1000 ? `${reportContent.slice(0, 997)}...` : reportContent }
      )
      .setFooter({ text: "Site-24 Records System | Document secured." })
      .setTimestamp();

    await interaction.reply({ embeds: [embed], components: [actionButtons(category)] });
    return;
  }

  const searchMatch = interaction.customId.match(/^records_modal_search_(incident|brief|anomaly|mtf|personnel|scp)$/);
  if (searchMatch) {
    const category = searchMatch[1] as ArchiveCategory;
    const query = interaction.fields.getTextInputValue("query");
    const docs = searchArchiveDocuments(category, query, 8);
    await interaction.reply({ embeds: [buildListEmbed(category, docs, "Search", query)], components: [actionButtons(category)] });
  }
}

export async function handleInteraction(interaction: Interaction) {
  if (interaction.isStringSelectMenu() && interaction.customId === "records_category") {
    await handleCategorySelect(interaction);
    return;
  }

  if (interaction.isButton() && interaction.customId.startsWith("records_")) {
    await handleButton(interaction);
    return;
  }

  if (interaction.isModalSubmit() && interaction.customId.startsWith("records_modal_")) {
    await handleModal(interaction);
  }
}
