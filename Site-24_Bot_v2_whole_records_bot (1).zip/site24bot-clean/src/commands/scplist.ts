import { SlashCommandBuilder, ChatInputCommandInteraction, EmbedBuilder } from "discord.js";
import { SCP_LIST } from "../data/scps.js";

export const data = new SlashCommandBuilder()
  .setName("scplist")
  .setDescription("View all SCP entities available for capture.");

export async function execute(interaction: ChatInputCommandInteraction) {
  const byClass: Record<string, typeof SCP_LIST> = {};
  for (const scp of SCP_LIST) {
    if (!byClass[scp.class]) byClass[scp.class] = [];
    byClass[scp.class].push(scp);
  }

  const classOrder = ["Safe", "Euclid", "Keter", "Thaumiel", "Neutralized"];
  const classEmojis: Record<string, string> = {
    Safe: "🟢",
    Euclid: "🟡",
    Keter: "🔴",
    Thaumiel: "🔵",
    Neutralized: "⚫",
  };

  const embed = new EmbedBuilder()
    .setColor(0x2f4f4f)
    .setTitle("📋 SCP Foundation — Available Entities")
    .setDescription(`**${SCP_LIST.length} SCPs** available for capture.\nUse \`/capture\` to attempt containment!`);

  for (const cls of classOrder) {
    if (!byClass[cls]) continue;
    const scps = byClass[cls];
    embed.addFields({
      name: `${classEmojis[cls]} ${cls} Class (${scps.length})`,
      value: scps
        .map((s) => `${s.emoji} **${s.id}** — ${s.captureChance}% | ${s.points}pts`)
        .join("\n"),
    });
  }

  embed.setFooter({ text: "Format: ID — Capture% | Points | SCP Foundation — Site-24" });

  await interaction.reply({ embeds: [embed] });
}
