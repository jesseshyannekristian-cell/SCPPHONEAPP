import "dotenv/config";
import {
  Client,
  GatewayIntentBits,
  Collection,
  Events,
  REST,
  Routes,
  type ChatInputCommandInteraction,
  type SlashCommandBuilder,
  type SlashCommandOptionsOnlyBuilder,
} from "discord.js";

import * as capture from "./commands/capture.js";
import * as daily from "./commands/daily.js";
import * as quiz from "./commands/quiz.js";
import * as leaderboard from "./commands/leaderboard.js";
import * as profile from "./commands/profile.js";
import * as collection from "./commands/collection.js";
import * as scpinfo from "./commands/scpinfo.js";
import * as scplist from "./commands/scplist.js";
import * as stats from "./commands/stats.js";
import * as mtf from "./commands/mtf.js";
import * as mtflist from "./commands/mtflist.js";
import * as mtfcompare from "./commands/mtfcompare.js";
import * as site from "./commands/site.js";
import * as ping from "./commands/ping.js";
import * as help from "./commands/help.js";
import * as reports from "./commands/reports.js";

interface Command {
  data: SlashCommandBuilder | SlashCommandOptionsOnlyBuilder;
  execute: (interaction: ChatInputCommandInteraction) => Promise<void>;
}

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.DISCORD_CLIENT_ID;

if (!TOKEN) { console.error("❌ DISCORD_TOKEN is not set in .env"); process.exit(1); }
if (!CLIENT_ID) { console.error("❌ DISCORD_CLIENT_ID is not set in .env"); process.exit(1); }

const commands: Command[] = [
  capture, daily, quiz, leaderboard, profile, collection,
  scpinfo, scplist, stats, mtf, mtflist, mtfcompare, site, ping, help, reports,
];

const commandMap = new Collection<string, Command>();
for (const cmd of commands) commandMap.set(cmd.data.name, cmd);

async function registerCommands() {
  const rest = new REST().setToken(TOKEN!);
  const commandData = commands.map((c) => c.data.toJSON());
  console.log(`📡 Registering ${commandData.length} slash commands...`);
  try {
    await rest.put(Routes.applicationCommands(CLIENT_ID!), { body: commandData });
    console.log(`✅ Successfully registered ${commandData.length} slash commands globally.`);
  } catch (err) {
    console.error("❌ Failed to register commands:", err);
  }
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

client.once(Events.ClientReady, async (c) => {
  console.log(`\n🤖 Site-24 Bot is online!`);
  console.log(`   Logged in as: ${c.user.tag}`);
  console.log(`   Bot ID: ${c.user.id}`);
  console.log(`   Serving ${c.guilds.cache.size} guild(s)\n`);
  await registerCommands();
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      const command = commandMap.get(interaction.commandName);
      if (!command) { console.warn(`⚠️ Unknown command: ${interaction.commandName}`); return; }
      await command.execute(interaction);
      return;
    }

    if (
      (interaction.isButton() || interaction.isStringSelectMenu() || interaction.isModalSubmit()) &&
      interaction.customId.startsWith("records_")
    ) {
      await reports.handleInteraction(interaction);
    }
  } catch (error) {
    console.error("❌ Error executing interaction:", error);
    const errorMsg = { content: "⚠️ An error occurred while executing this command.", ephemeral: true };
    if (interaction.isRepliable()) {
      if (interaction.replied || interaction.deferred) {
        await interaction.followUp(errorMsg).catch(() => {});
      } else {
        await interaction.reply(errorMsg).catch(() => {});
      }
    }
  }
});

client.on(Events.Error, (err) => console.error("Discord client error:", err));

console.log("🚀 Starting Site-24 Bot...");
client.login(TOKEN);
