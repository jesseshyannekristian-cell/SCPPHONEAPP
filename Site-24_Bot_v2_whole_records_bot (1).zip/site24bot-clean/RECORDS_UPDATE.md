# Site-24 Records System Update

This build adds a working `/reports` command with a full Discord Records Archive interface.

## What was added

- `/reports` archive hub with dropdown menu
- Buttons for each archive category:
  - ➕ Create
  - 📖 Browse
  - 🔍 Search
- Discord modals/forms for creating reports
- Discord modals/forms for searching archive sections
- SQLite-backed persistent archive storage in `data/site24.db`
- Automatic document IDs:
  - `IR-YYYY-0001` Incident Reports
  - `BR-YYYY-0001` Briefs
  - `AA-YYYY-0001` Anomaly Assessments
  - `MTF-YYYY-0001` MTF Dossiers
  - `PD-YYYY-0001` Personnel Dossiers
  - `SCP-YYYY-0001` SCP Dossiers
- No duplicate tabs: all document types are inside one archive system.

## Relaunch

Use your normal relaunch steps, usually:

```bash
npm install
npm run build
npm start
```

If you already have dependencies installed, you can usually run:

```bash
npm run build
npm start
```
